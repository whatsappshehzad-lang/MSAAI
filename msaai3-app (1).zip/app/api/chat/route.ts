import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { groq } from "@ai-sdk/groq"
import { generateText } from "ai"

const conversationContexts = new Map<string, Array<{ role: string; content: string }>>()

interface MultiModalResponse {
  text: string
  images?: Array<{ url: string; caption: string }>
  links?: Array<{ url: string; title: string; description?: string }>
  files?: Array<{ name: string; type: string; description: string }>
  suggestions?: string[]
}

function processCommand(message: string): { isCommand: boolean; command?: string; args?: string[]; mode?: string } {
  const commandRegex = /^\/(\w+)(?:\s+(.+))?$/
  const match = message.match(commandRegex)

  if (match) {
    const [, command, argsString] = match
    const args = argsString ? argsString.split(" ") : []
    return { isCommand: true, command, args }
  }

  // Check for smart mode indicators
  if (message.startsWith("[CODE MODE]")) {
    return { isCommand: true, mode: "code", args: [message.replace("[CODE MODE]", "").trim()] }
  }

  return { isCommand: false }
}

function getSystemPrompt(isFirstMessage = false, mode?: string, language = "en-US", hasFileContext = false): string {
  const langName = getLanguageName(language)

  let basePrompt = `You are **M.S.A.A.I (Multi-System Autonomous AI)** with multi-modal capabilities.

⚡ Answering Rules:
${isFirstMessage ? '- Introduce yourself once as "M.S.A.A.I".' : "- You have already introduced yourself, no need to do it again."}
- Do not mention creator unless asked.
- If asked "Who is your owner?" → reply: "My owner is Mohd Shehzad Ahmed. All rights reserved to the owner."
- Write clean answers with line breaks, bullets, and headings.
- Adapt tone: simple or detailed as per user request.
- IMPORTANT: Detect and reply in the user's language. Current language preference: ${langName}
- If unsure, say "I am not sure about this".
- Support commands: /summarize, /translate [text] [lang], /explain [topic].
- Remember conversation context until user ends chat.

⚡ Multi-Modal Capabilities:
- Provide links to relevant resources when helpful
- Suggest related images or diagrams when explaining concepts
- Offer file downloads or exports when appropriate
- Combine text, visual, and interactive elements in responses
- Always confirm before performing actions like generating images or files

⚡ Language Instructions:
- User's preferred language: ${langName} (${language})
- Always respond in ${langName} unless specifically asked to use another language
- Maintain natural, fluent communication in ${langName}
- For translation requests, clearly indicate source and target languages

${
  hasFileContext
    ? `⚡ File Analysis Context:
- You have access to uploaded file content
- Provide meaningful insights about uploaded files
- Offer to analyze, summarize, or process file content
- Suggest related actions based on file type and content`
    : ""
}

⚡ Ownership:
- Owner: Mohd Shehzad Ahmed
- All rights reserved to the owner.

Be helpful, intelligent, and maintain the M.S.A.A.I personality throughout the conversation.`

  // Add mode-specific instructions
  if (mode === "code") {
    basePrompt += `

🔧 CODE MODE ACTIVE:
- You are now in specialized programming mode
- Provide detailed code explanations, reviews, and solutions
- Include code examples with proper syntax highlighting
- Explain programming concepts clearly in ${langName}
- Help with debugging and optimization
- Support multiple programming languages
- Offer to generate code files or documentation when helpful`
  }

  return basePrompt
}

function getLanguageName(langCode: string): string {
  const languageNames: { [key: string]: string } = {
    "en-US": "English (US)",
    "en-GB": "English (UK)",
    "es-ES": "Spanish (Spain)",
    "es-MX": "Spanish (Mexico)",
    "fr-FR": "French",
    "de-DE": "German",
    "it-IT": "Italian",
    "pt-BR": "Portuguese (Brazil)",
    "zh-CN": "Chinese (Simplified)",
    "ja-JP": "Japanese",
    "ko-KR": "Korean",
    "ar-SA": "Arabic",
    "hi-IN": "Hindi",
    "ru-RU": "Russian",
  }
  return languageNames[langCode] || "English"
}

function generateRelevantLinks(topic: string): Array<{ url: string; title: string; description?: string }> {
  const links: Array<{ url: string; title: string; description?: string }> = []

  // Programming and tech topics
  if (topic.toLowerCase().includes("javascript") || topic.toLowerCase().includes("js")) {
    links.push({
      url: "https://developer.mozilla.org/en-US/docs/Web/JavaScript",
      title: "MDN JavaScript Documentation",
      description: "Comprehensive JavaScript reference and tutorials",
    })
  }

  if (topic.toLowerCase().includes("react")) {
    links.push({
      url: "https://react.dev/",
      title: "React Official Documentation",
      description: "Learn React from the official documentation",
    })
  }

  if (topic.toLowerCase().includes("python")) {
    links.push({
      url: "https://docs.python.org/3/",
      title: "Python Documentation",
      description: "Official Python 3 documentation",
    })
  }

  // AI and Machine Learning
  if (topic.toLowerCase().includes("ai") || topic.toLowerCase().includes("machine learning")) {
    links.push({
      url: "https://www.tensorflow.org/",
      title: "TensorFlow",
      description: "Open source machine learning platform",
    })
  }

  // Design and UI
  if (topic.toLowerCase().includes("design") || topic.toLowerCase().includes("ui")) {
    links.push({
      url: "https://www.figma.com/",
      title: "Figma",
      description: "Collaborative design tool",
    })
  }

  return links
}

function createMultiModalResponse(text: string, topic: string, mode?: string): MultiModalResponse {
  const response: MultiModalResponse = { text }

  // Add relevant links
  const links = generateRelevantLinks(topic)
  if (links.length > 0) {
    response.links = links
  }

  // Add suggestions based on content
  const suggestions: string[] = []

  if (mode === "code") {
    suggestions.push("Generate a code example", "Explain best practices", "Show debugging tips")
  } else if (topic.toLowerCase().includes("image") || topic.toLowerCase().includes("visual")) {
    suggestions.push("Generate an image", "Create a diagram", "Show visual examples")
  } else if (topic.toLowerCase().includes("data") || topic.toLowerCase().includes("analysis")) {
    suggestions.push("Create a chart", "Export data", "Generate report")
  } else {
    suggestions.push("Get more details", "See related topics", "Ask follow-up questions")
  }

  response.suggestions = suggestions

  return response
}

export async function POST(request: NextRequest) {
  try {
    const { message, language = "en-US", fileContext } = await request.json()
    const supabase = await createClient()

    // Get the current user
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = user.id
    if (!conversationContexts.has(userId)) {
      conversationContexts.set(userId, [])
    }
    const context = conversationContexts.get(userId)!
    const isFirstMessage = context.length === 0

    const { isCommand, command, args, mode } = processCommand(message)

    let responseMessage = message
    let systemPrompt = getSystemPrompt(isFirstMessage, mode, language, !!fileContext)

    if (fileContext) {
      systemPrompt += `\n\nFile Context: The user has uploaded a file: ${fileContext.name} (${fileContext.type}). ${fileContext.analysis || ""}`
      responseMessage += `\n\n[File uploaded: ${fileContext.name}]`
    }

    if (isCommand) {
      if (mode === "code") {
        responseMessage = args?.[0] || message
        systemPrompt +=
          "\n\nThe user is asking for programming help. Provide detailed, technical assistance with code examples and best practices."
      } else {
        switch (command) {
          case "summarize":
            systemPrompt +=
              "\n\nThe user wants you to summarize the previous conversation or content. Provide a concise summary with key points."
            responseMessage = `Please summarize: ${args?.join(" ") || "our conversation"}`
            break
          case "translate":
            if (args && args.length >= 2) {
              const textToTranslate = args.slice(0, -1).join(" ")
              const targetLang = args[args.length - 1]
              systemPrompt += `\n\nTranslate the following text to ${targetLang}: "${textToTranslate}"`
              responseMessage = `Translate "${textToTranslate}" to ${targetLang}`
            } else {
              responseMessage = "Please use format: /translate [text] [language]"
            }
            break
          case "explain":
            const topic = args?.join(" ")
            const isSimple = topic?.includes("(explain in simple terms)")
            const isDeep = topic?.includes("(provide detailed explanation)")

            if (isSimple) {
              systemPrompt += `\n\nProvide a simple, easy-to-understand explanation of: ${topic?.replace("(explain in simple terms)", "").trim()}`
            } else if (isDeep) {
              systemPrompt += `\n\nProvide a detailed, comprehensive explanation of: ${topic?.replace("(provide detailed explanation)", "").trim()}`
            } else {
              systemPrompt += `\n\nProvide a detailed explanation of: ${topic}`
            }
            responseMessage = `Explain: ${topic}`
            break
          default:
            responseMessage = `Unknown command: /${command}. Available commands: /summarize, /translate [text] [lang], /explain [topic]`
        }
      }
    }

    try {
      const messages = [
        { role: "system", content: systemPrompt },
        ...context,
        { role: "user", content: responseMessage },
      ]

      const { text } = await generateText({
        model: groq("llama3-70b-8192"),
        messages: messages as any,
        maxTokens: 1000,
        temperature: mode === "code" ? 0.3 : 0.7,
      })

      context.push({ role: "user", content: message })
      context.push({ role: "assistant", content: text })

      // Keep only last 10 exchanges to manage memory
      if (context.length > 20) {
        context.splice(0, context.length - 20)
      }

      const multiModalResponse = createMultiModalResponse(text, message, mode)

      return NextResponse.json({
        response: multiModalResponse.text,
        multiModal: multiModalResponse,
      })
    } catch (aiError) {
      console.error("AI generation error:", aiError)
      const fallbackResponse = `I'm M.S.A.A.I, your Multi-System Autonomous AI assistant. I received your message: "${message}". I'm currently experiencing some technical difficulties with my AI systems, but I'm here to help you. Please try again in a moment.`
      return NextResponse.json({ response: fallbackResponse })
    }
  } catch (error) {
    console.error("Chat API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
