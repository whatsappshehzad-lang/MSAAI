import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createServerClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Validate file type and size
    const maxSize = 10 * 1024 * 1024 // 10MB
    if (file.size > maxSize) {
      return NextResponse.json({ error: "File too large. Maximum size is 10MB." }, { status: 400 })
    }

    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/webp",
      "application/pdf",
      "text/plain",
      "application/json",
      "text/csv",
      "application/vnd.ms-excel",
    ]

    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json(
        {
          error: "Unsupported file type. Supported: images, PDF, text, CSV, Excel",
        },
        { status: 400 },
      )
    }

    // Convert file to base64 for storage (in a real app, you'd use proper file storage)
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const base64 = buffer.toString("base64")
    const dataUrl = `data:${file.type};base64,${base64}`

    // Analyze file content based on type
    let analysis = ""
    if (file.type.startsWith("image/")) {
      analysis = "Image uploaded successfully. You can ask me to analyze or describe this image."
    } else if (file.type === "application/pdf") {
      analysis = "PDF document uploaded. I can help you extract information or summarize the content."
    } else if (file.type.startsWith("text/")) {
      const text = buffer.toString("utf-8")
      analysis = `Text file uploaded with ${text.length} characters. I can help analyze or process this content.`
    } else {
      analysis = "File uploaded successfully. I can help you work with this file."
    }

    return NextResponse.json({
      success: true,
      file: {
        name: file.name,
        type: file.type,
        size: file.size,
        url: dataUrl,
        analysis,
      },
    })
  } catch (error) {
    console.error("File upload error:", error)
    return NextResponse.json({ error: "Failed to upload file" }, { status: 500 })
  }
}
