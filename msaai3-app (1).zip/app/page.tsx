"use client"

import type React from "react"
import { Upload, FileText } from "lucide-react"
import { MultiModalMessage } from "@/components/multi-modal-message"
import { ConfirmationDialog } from "@/components/confirmation-dialog"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import type { User } from "@supabase/supabase-js"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Mic, MicOff, Volume2, VolumeX, Send, UserIcon, Sparkles, Moon, Sun, Languages } from "lucide-react"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import Image from "next/image"
import type { SpeechRecognition, SpeechSynthesis } from "web-speech-api"
import { ChatSidebar } from "@/components/chat-sidebar"
import { SmartModes } from "@/components/smart-modes"
import { EnhancedMessage } from "@/components/enhanced-message"
import { ChatActions } from "@/components/chat-actions"
import { LanguageSettings } from "@/components/language-settings"
import { ImageGenerator } from "@/components/image-generator"
import { FileUpload } from "@/components/file-upload"
import { useTheme } from "next-themes"
import { Toaster } from "sonner"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  created_at: string
  imageUrl?: string
  imagePrompt?: string
  fileUrl?: string
  fileName?: string
  fileType?: string
  fileAnalysis?: string
  multiModal?: any
}

export default function HomePage() {
  const [user, setUser] = useState<User | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null)
  const [synthesis, setSynthesis] = useState<SpeechSynthesis | null>(null)
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [smartModesOpen, setSmartModesOpen] = useState(false)
  const [languageSettingsOpen, setLanguageSettingsOpen] = useState(false)
  const [imageGeneratorOpen, setImageGeneratorOpen] = useState(false)
  const [fileUploadOpen, setFileUploadOpen] = useState(false)
  const [currentLanguage, setCurrentLanguage] = useState("en-US")
  const [currentVoice, setCurrentVoice] = useState("")
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([])
  const { theme, setTheme } = useTheme()
  const [showImageConfirmation, setShowImageConfirmation] = useState(false)
  const [pendingImagePrompt, setPendingImagePrompt] = useState("")

  const supabase = createClient()

  useEffect(() => {
    // Get initial user
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user)
    })

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null)
    })

    // Initialize speech recognition and synthesis
    if (typeof window !== "undefined") {
      if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
        const recognitionInstance = new SpeechRecognition()
        recognitionInstance.continuous = false
        recognitionInstance.interimResults = false
        recognitionInstance.lang = currentLanguage

        recognitionInstance.onresult = (event) => {
          const transcript = event.results[0][0].transcript
          setInput(transcript)
          setIsListening(false)
        }

        recognitionInstance.onerror = () => {
          setIsListening(false)
        }

        recognitionInstance.onend = () => {
          setIsListening(false)
        }

        setRecognition(recognitionInstance)
      }

      if ("speechSynthesis" in window) {
        setSynthesis(window.speechSynthesis)

        const loadVoices = () => {
          const voices = window.speechSynthesis.getVoices()
          setAvailableVoices(voices)

          // Set default voice for current language
          if (!currentVoice && voices.length > 0) {
            const langPrefix = currentLanguage.split("-")[0]
            const preferredVoice = voices.find(
              (voice) => voice.lang.startsWith(langPrefix) || voice.lang.startsWith(currentLanguage),
            )
            if (preferredVoice) {
              setCurrentVoice(preferredVoice.name)
            }
          }
        }

        loadVoices()
        window.speechSynthesis.onvoiceschanged = loadVoices
      }
    }

    return () => subscription.unsubscribe()
  }, [currentLanguage, currentVoice])

  useEffect(() => {
    if (recognition) {
      recognition.lang = currentLanguage
    }
  }, [currentLanguage, recognition])

  const toggleListening = () => {
    if (!recognition) return

    if (isListening) {
      recognition.stop()
      setIsListening(false)
    } else {
      recognition.start()
      setIsListening(true)
    }
  }

  const speak = (text: string) => {
    if (!synthesis) return

    synthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)

    // Set the selected voice
    if (currentVoice) {
      const voice = availableVoices.find((v) => v.name === currentVoice)
      if (voice) {
        utterance.voice = voice
      }
    }

    utterance.onstart = () => setIsSpeaking(true)
    utterance.onend = () => setIsSpeaking(false)
    synthesis.speak(utterance)
  }

  const stopSpeaking = () => {
    if (synthesis) {
      synthesis.cancel()
      setIsSpeaking(false)
    }
  }

  const handleImageGenerated = (imageUrl: string, prompt: string) => {
    const imageMessage: Message = {
      id: Date.now().toString(),
      content: `Generated image: "${prompt}"`,
      role: "assistant",
      created_at: new Date().toISOString(),
      imageUrl,
      imagePrompt: prompt,
    }
    setMessages((prev) => [...prev, imageMessage])
    setImageGeneratorOpen(false)
  }

  const handleFileUploaded = (file: any) => {
    const fileMessage: Message = {
      id: Date.now().toString(),
      content: `Uploaded file: ${file.name}`,
      role: "user",
      created_at: new Date().toISOString(),
      fileUrl: file.url,
      fileName: file.name,
      fileType: file.type,
      fileAnalysis: file.analysis,
    }
    setMessages((prev) => [...prev, fileMessage])

    // Add AI response about the file
    const aiResponse: Message = {
      id: (Date.now() + 1).toString(),
      content: file.analysis,
      role: "assistant",
      created_at: new Date().toISOString(),
    }
    setMessages((prev) => [...prev, aiResponse])

    setFileUploadOpen(false)
    speak(file.analysis)
  }

  const sendMessage = async (messageContent?: string) => {
    const content = messageContent || input
    if (!content.trim() || !user) return

    setInput("")
    setIsLoading(true)

    try {
      // Check if this is an image generation request
      const imageKeywords = ["generate image", "create image", "draw", "make image", "generate picture"]
      const isImageRequest = imageKeywords.some((keyword) => content.toLowerCase().includes(keyword))

      if (isImageRequest) {
        // Extract the image prompt from the message
        let imagePrompt = content
        imageKeywords.forEach((keyword) => {
          const regex = new RegExp(`${keyword}[:\\s]+(.+)`, "i")
          const match = content.match(regex)
          if (match) {
            imagePrompt = match[1].trim()
          }
        })

        setPendingImagePrompt(imagePrompt)
        setShowImageConfirmation(true)
        setIsLoading(false)
        return
      }

      // Create conversation if none exists
      let conversationId = currentConversationId
      if (!conversationId) {
        const response = await fetch("/api/conversations", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: content.substring(0, 50) + "..." }),
        })
        const data = await response.json()
        conversationId = data.conversation.id
        setCurrentConversationId(conversationId)
      }

      // Save user message to database
      await fetch(`/api/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: "user", content }),
      })

      const userMessage: Message = {
        id: Date.now().toString(),
        content,
        role: "user",
        created_at: new Date().toISOString(),
      }

      setMessages((prev) => [...prev, userMessage])

      const chatPayload: any = {
        message: content,
        language: currentLanguage,
      }

      // Add file context if there are recent file uploads
      const recentFileMessage = messages.slice(-3).find((m) => m.fileUrl)
      if (recentFileMessage) {
        chatPayload.fileContext = {
          name: recentFileMessage.fileName,
          type: recentFileMessage.fileType,
          analysis: recentFileMessage.fileAnalysis,
        }
      }

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(chatPayload),
      })

      const data = await response.json()
      const assistantContent = data.response || "I'm here to help! This is a simulated response."

      // Save assistant message to database
      await fetch(`/api/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: "assistant", content: assistantContent }),
      })

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: assistantContent,
        role: "assistant",
        created_at: new Date().toISOString(),
        multiModal: data.multiModal, // Store multi-modal content
      }

      setMessages((prev) => [...prev, assistantMessage])

      // Auto-speak the response
      speak(assistantMessage.content)
    } catch (error) {
      console.error("Error sending message:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleConfirmImageGeneration = async () => {
    setShowImageConfirmation(false)
    setIsLoading(true)

    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: pendingImagePrompt }),
      })

      const data = await response.json()

      if (data.success) {
        handleImageGenerated(data.imageUrl, data.prompt)
      } else {
        console.error("Image generation failed:", data.error)
      }
    } catch (error) {
      console.error("Error generating image:", error)
    } finally {
      setIsLoading(false)
      setPendingImagePrompt("")
    }
  }

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion)
    setTimeout(() => sendMessage(suggestion), 100)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const handleConversationSelect = async (conversationId: string) => {
    try {
      const response = await fetch(`/api/conversations?search=`)
      const data = await response.json()
      const conversation = data.conversations.find((c: any) => c.id === conversationId)

      if (conversation) {
        setCurrentConversationId(conversationId)
        setMessages(conversation.messages || [])
      }
    } catch (error) {
      console.error("Error loading conversation:", error)
    }
  }

  const handleNewConversation = () => {
    setCurrentConversationId(null)
    setMessages([])
  }

  const handleSmartModeSelect = (mode: string, prompt: string) => {
    setInput(prompt)
    // Auto-send the smart mode prompt
    setTimeout(() => sendMessage(prompt), 100)
  }

  const handleRegenerate = async (messageId: string) => {
    // Find the message and regenerate the response
    const messageIndex = messages.findIndex((m) => m.id === messageId)
    if (messageIndex === -1 || messageIndex === 0) return

    const previousMessage = messages[messageIndex - 1]
    if (previousMessage.role !== "user") return

    setIsLoading(true)
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: previousMessage.content }),
      })

      const data = await response.json()
      const newContent = data.response || "I'm here to help! This is a regenerated response."

      // Update the message
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === messageId ? { ...msg, content: newContent, created_at: new Date().toISOString() } : msg,
        ),
      )

      speak(newContent)
    } catch (error) {
      console.error("Error regenerating message:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleLanguageChange = (language: string) => {
    setCurrentLanguage(language)

    // Update recognition language
    if (recognition) {
      recognition.lang = language
    }
  }

  const handleVoiceChange = (voiceName: string) => {
    setCurrentVoice(voiceName)
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 text-center">
          <div className="mb-6">
            <div className="flex justify-center mb-4">
              <Image src="/images/msaai-logo.png" alt="M.S.A.A.I Logo" width={64} height={64} className="rounded-lg" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">M.S.A.A.I</h1>
            <p className="text-gray-600 dark:text-gray-400">Multi-System Autonomous Artificial Intelligence</p>
          </div>

          <div className="space-y-4">
            <Link href="/auth/login">
              <Button className="w-full" size="lg">
                Login
              </Button>
            </Link>
            <Link href="/auth/sign-up">
              <Button variant="outline" className="w-full bg-transparent" size="lg">
                Sign Up
              </Button>
            </Link>
          </div>
        </Card>
        <Toaster />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 flex">
      <ChatSidebar
        currentConversationId={currentConversationId}
        onConversationSelect={handleConversationSelect}
        onNewConversation={handleNewConversation}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />

      <SmartModes
        onModeSelect={handleSmartModeSelect}
        isOpen={smartModesOpen}
        onClose={() => setSmartModesOpen(false)}
      />

      <LanguageSettings
        isOpen={languageSettingsOpen}
        onClose={() => setLanguageSettingsOpen(false)}
        currentLanguage={currentLanguage}
        onLanguageChange={handleLanguageChange}
        currentVoice={currentVoice}
        onVoiceChange={handleVoiceChange}
      />

      {fileUploadOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <FileUpload onFileUploaded={handleFileUploaded} onClose={() => setFileUploadOpen(false)} />
          </div>
        </div>
      )}

      {imageGeneratorOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
              <h2 className="text-lg font-semibold">Image Generator</h2>
              <Button variant="ghost" size="sm" onClick={() => setImageGeneratorOpen(false)}>
                ✕
              </Button>
            </div>
            <div className="p-4">
              <ImageGenerator onImageGenerated={handleImageGenerated} />
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 flex flex-col md:ml-0">
        {/* Header */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={() => setSidebarOpen(!sidebarOpen)} className="md:hidden">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </Button>
              <div className="flex items-center space-x-3">
                <Image
                  src="/images/msaai-logo.png"
                  alt="M.S.A.A.I Logo"
                  width={40}
                  height={40}
                  className="rounded-lg"
                />
                <div>
                  <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">M.S.A.A.I</h1>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Multi-System Autonomous AI</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
                {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setLanguageSettingsOpen(true)}>
                <Languages className="w-4 h-4 mr-2" />
                Language
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setSmartModesOpen(true)}>
                <Sparkles className="w-4 h-4 mr-2" />
                Smart Modes
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setImageGeneratorOpen(true)}>
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
                Images
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setFileUploadOpen(true)}>
                <Upload className="w-4 h-4 mr-2" />
                Upload
              </Button>
              <ChatActions messages={messages} conversationTitle="M.S.A.A.I Chat" />
              <Link href="/profile">
                <Button variant="ghost" size="sm">
                  <UserIcon className="w-4 h-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Button variant="outline" onClick={() => supabase.auth.signOut()}>
                Sign Out
              </Button>
            </div>
          </div>
        </div>

        {/* Main Chat Interface */}
        <div className="flex-1 max-w-4xl mx-auto w-full p-4 flex flex-col">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto mb-4 space-y-4">
            {messages.length === 0 ? (
              <div className="text-center py-12">
                <div className="flex justify-center mb-4">
                  <Image
                    src="/images/msaai-logo.png"
                    alt="M.S.A.A.I Logo"
                    width={80}
                    height={80}
                    className="rounded-lg"
                  />
                </div>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">Welcome to M.S.A.A.I</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-4">Your Multi-System Autonomous AI Assistant</p>
                <p className="text-sm text-gray-500 dark:text-gray-500 mb-4">
                  Use voice commands, type messages, or generate images. Wake word: "MSAAI"
                </p>
                <div className="flex flex-col sm:flex-row gap-2 justify-center">
                  <Button variant="outline" onClick={() => setSmartModesOpen(true)}>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Try Smart Modes
                  </Button>
                  <Button variant="outline" onClick={() => setImageGeneratorOpen(true)}>
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                    Generate Images
                  </Button>
                  <Button variant="outline" onClick={() => setLanguageSettingsOpen(true)}>
                    <Languages className="w-4 h-4 mr-2" />
                    Choose Language
                  </Button>
                </div>
              </div>
            ) : (
              messages.map((message) => (
                <div key={message.id}>
                  {message.multiModal ? (
                    <div className="flex justify-start mb-4">
                      <div className="bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 border border-gray-200 dark:border-gray-700 max-w-3xl px-4 py-3 rounded-lg">
                        <MultiModalMessage content={message.multiModal} onSuggestionClick={handleSuggestionClick} />
                      </div>
                    </div>
                  ) : (
                    <EnhancedMessage message={message} onRegenerate={handleRegenerate} />
                  )}
                  {message.imageUrl && (
                    <div className="mt-2 flex justify-start">
                      <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4 max-w-md">
                        <img
                          src={message.imageUrl || "/placeholder.svg"}
                          alt={message.imagePrompt || "Generated image"}
                          className="w-full rounded-lg shadow-lg mb-2"
                        />
                        {message.imagePrompt && (
                          <p className="text-sm text-gray-600 dark:text-gray-400">"{message.imagePrompt}"</p>
                        )}
                      </div>
                    </div>
                  )}
                  {message.fileUrl && (
                    <div className="mt-2 flex justify-start">
                      <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4 max-w-md">
                        {message.fileType?.startsWith("image/") ? (
                          <img
                            src={message.fileUrl || "/placeholder.svg"}
                            alt={message.fileName || "Uploaded file"}
                            className="w-full rounded-lg shadow-lg mb-2"
                          />
                        ) : (
                          <div className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                            <FileText className="h-8 w-8 text-gray-500" />
                            <div>
                              <p className="font-medium">{message.fileName}</p>
                              <p className="text-sm text-gray-500">{message.fileType}</p>
                            </div>
                          </div>
                        )}
                        {message.fileAnalysis && (
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">{message.fileAnalysis}</p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 border border-gray-200 dark:border-gray-700 max-w-xs lg:max-w-md px-4 py-2 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div
                      className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                      style={{ animationDelay: "0.1s" }}
                    ></div>
                    <div
                      className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                      style={{ animationDelay: "0.2s" }}
                    ></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <Card className="p-4">
            <div className="flex items-center space-x-2">
              <Button
                variant={isListening ? "default" : "outline"}
                size="icon"
                onClick={toggleListening}
                disabled={!recognition}
                className={isListening ? "bg-red-600 hover:bg-red-700" : ""}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>

              <Button
                variant="outline"
                size="icon"
                onClick={isSpeaking ? stopSpeaking : () => {}}
                disabled={!synthesis}
                className={isSpeaking ? "bg-green-600 hover:bg-green-700 text-white" : ""}
              >
                {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>

              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={
                  isListening ? "Listening..." : "Type your message, ask to generate an image, or use voice..."
                }
                className="flex-1"
                disabled={isListening}
              />

              <Button variant="outline" size="icon" onClick={() => setSmartModesOpen(true)} title="Smart Modes">
                <Sparkles className="w-4 h-4" />
              </Button>

              <Button variant="outline" size="icon" onClick={() => setImageGeneratorOpen(true)} title="Generate Image">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </Button>

              <Button variant="outline" size="icon" onClick={() => setFileUploadOpen(true)} title="Upload File">
                <Upload className="w-4 h-4" />
              </Button>

              <Button onClick={() => sendMessage()} disabled={!input.trim() || isLoading} size="icon">
                <Send className="w-4 h-4" />
              </Button>
            </div>

            <div className="mt-2 flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
              <div className="flex items-center space-x-4">
                <span className={`flex items-center ${isListening ? "text-red-600 dark:text-red-400" : ""}`}>
                  <div
                    className={`w-2 h-2 rounded-full mr-1 ${isListening ? "bg-red-600 animate-pulse" : "bg-gray-300 dark:bg-gray-600"}`}
                  ></div>
                  Speech Recognition {isListening ? "Active" : "Ready"}
                </span>
                <span className={`flex items-center ${isSpeaking ? "text-green-600 dark:text-green-400" : ""}`}>
                  <div
                    className={`w-2 h-2 rounded-full mr-1 ${isSpeaking ? "bg-green-600 animate-pulse" : "bg-gray-300 dark:bg-gray-600"}`}
                  ></div>
                  Voice Output {isSpeaking ? "Speaking" : "Ready"}
                </span>
              </div>
              <span>Language: {currentLanguage.split("-")[0].toUpperCase()}</span>
            </div>
          </Card>
        </div>
      </div>
      <ConfirmationDialog
        isOpen={showImageConfirmation}
        onClose={() => {
          setShowImageConfirmation(false)
          setPendingImagePrompt("")
        }}
        onConfirm={handleConfirmImageGeneration}
        title="Generate Image"
        message="Do you want to generate an image based on your message?"
        confirmText="Generate"
        cancelText="Cancel"
        type="info"
        details={[
          `Prompt: "${pendingImagePrompt}"`,
          "This will use AI resources to create your image",
          "The generated image will appear in the chat",
        ]}
      />
      <Toaster />
    </div>
  )
}
