"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Languages, X, Mic, Volume2 } from "lucide-react"
import { toast } from "sonner"

interface LanguageSettingsProps {
  isOpen: boolean
  onClose: () => void
  currentLanguage: string
  onLanguageChange: (language: string) => void
  currentVoice: string
  onVoiceChange: (voice: string) => void
}

const SUPPORTED_LANGUAGES = [
  { code: "en-US", name: "English (US)", flag: "🇺🇸" },
  { code: "en-GB", name: "English (UK)", flag: "🇬🇧" },
  { code: "es-ES", name: "Spanish (Spain)", flag: "🇪🇸" },
  { code: "es-MX", name: "Spanish (Mexico)", flag: "🇲🇽" },
  { code: "fr-FR", name: "French", flag: "🇫🇷" },
  { code: "de-DE", name: "German", flag: "🇩🇪" },
  { code: "it-IT", name: "Italian", flag: "🇮🇹" },
  { code: "pt-BR", name: "Portuguese (Brazil)", flag: "🇧🇷" },
  { code: "zh-CN", name: "Chinese (Simplified)", flag: "🇨🇳" },
  { code: "ja-JP", name: "Japanese", flag: "🇯🇵" },
  { code: "ko-KR", name: "Korean", flag: "🇰🇷" },
  { code: "ar-SA", name: "Arabic", flag: "🇸🇦" },
  { code: "hi-IN", name: "Hindi", flag: "🇮🇳" },
  { code: "ru-RU", name: "Russian", flag: "🇷🇺" },
]

export function LanguageSettings({
  isOpen,
  onClose,
  currentLanguage,
  onLanguageChange,
  currentVoice,
  onVoiceChange,
}: LanguageSettingsProps) {
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([])
  const [testingVoice, setTestingVoice] = useState(false)

  useEffect(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices()
        setAvailableVoices(voices)
      }

      loadVoices()
      window.speechSynthesis.onvoiceschanged = loadVoices
    }
  }, [])

  const getVoicesForLanguage = (langCode: string) => {
    const langPrefix = langCode.split("-")[0]
    return availableVoices.filter((voice) => voice.lang.startsWith(langPrefix) || voice.lang.startsWith(langCode))
  }

  const testVoice = (voiceName: string) => {
    if (testingVoice) return

    setTestingVoice(true)
    const utterance = new SpeechSynthesisUtterance("Hello! This is how I sound in this voice.")
    const voice = availableVoices.find((v) => v.name === voiceName)
    if (voice) {
      utterance.voice = voice
    }
    utterance.onend = () => setTestingVoice(false)
    utterance.onerror = () => setTestingVoice(false)

    window.speechSynthesis.speak(utterance)
  }

  const handleLanguageChange = (newLanguage: string) => {
    onLanguageChange(newLanguage)

    // Auto-select a suitable voice for the new language
    const voicesForLang = getVoicesForLanguage(newLanguage)
    if (voicesForLang.length > 0) {
      onVoiceChange(voicesForLang[0].name)
    }

    toast.success(`Language changed to ${SUPPORTED_LANGUAGES.find((l) => l.code === newLanguage)?.name}`)
  }

  if (!isOpen) return null

  const currentLangInfo = SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage)
  const voicesForCurrentLang = getVoicesForLanguage(currentLanguage)

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <Languages className="w-5 h-5 mr-2" />
                Language & Voice Settings
              </CardTitle>
              <CardDescription>
                Configure your preferred language for speech recognition and voice output
              </CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Language Selection */}
          <div className="space-y-3">
            <Label className="flex items-center text-base font-medium">
              <Mic className="w-4 h-4 mr-2" />
              Speech Recognition Language
            </Label>
            <Select value={currentLanguage} onValueChange={handleLanguageChange}>
              <SelectTrigger>
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    <div className="flex items-center space-x-2">
                      <span>{lang.flag}</span>
                      <span>{lang.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Current: {currentLangInfo?.flag} {currentLangInfo?.name}
            </p>
          </div>

          {/* Voice Selection */}
          <div className="space-y-3">
            <Label className="flex items-center text-base font-medium">
              <Volume2 className="w-4 h-4 mr-2" />
              Voice Output
            </Label>
            {voicesForCurrentLang.length > 0 ? (
              <>
                <Select value={currentVoice} onValueChange={onVoiceChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select voice" />
                  </SelectTrigger>
                  <SelectContent>
                    {voicesForCurrentLang.map((voice) => (
                      <SelectItem key={voice.name} value={voice.name}>
                        <div className="flex items-center justify-between w-full">
                          <span>{voice.name}</span>
                          <span className="text-xs text-gray-500 ml-2">{voice.lang}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" onClick={() => testVoice(currentVoice)} disabled={testingVoice}>
                    {testingVoice ? "Testing..." : "Test Voice"}
                  </Button>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Click to hear a sample</p>
                </div>
              </>
            ) : (
              <p className="text-sm text-gray-500 dark:text-gray-400">
                No voices available for the selected language. The system will use the default voice.
              </p>
            )}
          </div>

          {/* Language Features Info */}
          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">Language Features</h4>
            <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
              <li>• M.S.A.A.I will automatically detect and respond in your selected language</li>
              <li>• Voice recognition adapts to your chosen language's accent and pronunciation</li>
              <li>• All AI responses will be optimized for your language preferences</li>
              <li>• Smart Modes (translate, explain) work seamlessly across languages</li>
            </ul>
          </div>

          <div className="flex justify-end">
            <Button onClick={onClose}>Done</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
