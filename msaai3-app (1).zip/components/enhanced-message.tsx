"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Copy, RotateCcw, ThumbsUp, ThumbsDown, Check, User, Bot } from "lucide-react"
import { toast } from "sonner"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  created_at: string
}

interface EnhancedMessageProps {
  message: Message
  onRegenerate?: (messageId: string) => void
  onLike?: (messageId: string) => void
  onDislike?: (messageId: string) => void
}

export function EnhancedMessage({ message, onRegenerate, onLike, onDislike }: EnhancedMessageProps) {
  const [copied, setCopied] = useState(false)
  const [liked, setLiked] = useState<boolean | null>(null)

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content)
      setCopied(true)
      toast.success("Message copied to clipboard")
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      toast.error("Failed to copy message")
    }
  }

  const handleLike = () => {
    const newLiked = liked === true ? null : true
    setLiked(newLiked)
    if (onLike) onLike(message.id)
    toast.success(newLiked ? "Message liked" : "Like removed")
  }

  const handleDislike = () => {
    const newLiked = liked === false ? null : false
    setLiked(newLiked)
    if (onDislike) onDislike(message.id)
    toast.success(newLiked === false ? "Message disliked" : "Dislike removed")
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const isUser = message.role === "user"

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} group`}>
      <div className={`max-w-xs lg:max-w-md ${isUser ? "order-2" : "order-1"}`}>
        {/* Message bubble */}
        <div
          className={`px-4 py-3 rounded-lg ${
            isUser
              ? "bg-blue-600 text-white dark:bg-blue-500"
              : "bg-white text-gray-900 border border-gray-200 dark:bg-gray-800 dark:text-gray-100 dark:border-gray-700"
          }`}
        >
          <div className="flex items-start space-x-2 mb-2">
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                isUser ? "bg-blue-500" : "bg-gray-100 dark:bg-gray-700"
              }`}
            >
              {isUser ? <User className="w-3 h-3" /> : <Bot className="w-3 h-3" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs opacity-70 mb-1">
                {isUser ? "You" : "M.S.A.A.I"} • {formatTime(message.created_at)}
              </div>
            </div>
          </div>
          <div className="whitespace-pre-wrap break-words">{message.content}</div>
        </div>

        {/* Action buttons */}
        <div
          className={`flex items-center space-x-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity ${
            isUser ? "justify-end" : "justify-start"
          }`}
        >
          <Button variant="ghost" size="sm" onClick={handleCopy} className="h-8 px-2 text-xs">
            {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
          </Button>

          {!isUser && onRegenerate && (
            <Button variant="ghost" size="sm" onClick={() => onRegenerate(message.id)} className="h-8 px-2 text-xs">
              <RotateCcw className="w-3 h-3" />
            </Button>
          )}

          {!isUser && (
            <>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLike}
                className={`h-8 px-2 text-xs ${liked === true ? "text-green-600 dark:text-green-400" : ""}`}
              >
                <ThumbsUp className="w-3 h-3" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDislike}
                className={`h-8 px-2 text-xs ${liked === false ? "text-red-600 dark:text-red-400" : ""}`}
              >
                <ThumbsDown className="w-3 h-3" />
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
