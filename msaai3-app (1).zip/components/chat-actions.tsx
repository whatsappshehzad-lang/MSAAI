"use client"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { Download, FileText, File, ImageIcon, Archive, FileJson } from "lucide-react"
import { toast } from "sonner"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  created_at: string
  imageUrl?: string
  imagePrompt?: string
  fileUrl?: string
  fileName?: string
  fileType?: string
  fileAnalysis?: string
  multiModal?: any
}

interface ChatActionsProps {
  messages: Message[]
  conversationTitle?: string
}

export function ChatActions({ messages, conversationTitle = "M.S.A.A.I Chat" }: ChatActionsProps) {
  const downloadAsText = () => {
    if (messages.length === 0) {
      toast.error("No messages to download")
      return
    }

    const content = messages
      .map((msg) => {
        const timestamp = new Date(msg.created_at).toLocaleString()
        const sender = msg.role === "user" ? "You" : "M.S.A.A.I"
        let messageContent = `[${timestamp}] ${sender}: ${msg.content}`

        if (msg.imageUrl && msg.imagePrompt) {
          messageContent += `\n  [Generated Image: "${msg.imagePrompt}"]`
        }
        if (msg.fileUrl && msg.fileName) {
          messageContent += `\n  [Uploaded File: ${msg.fileName} (${msg.fileType})]`
          if (msg.fileAnalysis) {
            messageContent += `\n  [Analysis: ${msg.fileAnalysis}]`
          }
        }
        if (msg.multiModal?.links && msg.multiModal.links.length > 0) {
          messageContent += `\n  [Links: ${msg.multiModal.links.map((link: any) => `${link.title} - ${link.url}`).join(", ")}]`
        }

        return messageContent
      })
      .join("\n\n")

    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${conversationTitle}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast.success("Chat downloaded as text file")
  }

  const downloadAsPDF = () => {
    // For now, we'll create a formatted HTML version that can be printed as PDF
    if (messages.length === 0) {
      toast.error("No messages to download")
      return
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${conversationTitle}</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; line-height: 1.6; }
          .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #eee; padding-bottom: 20px; }
          .message { margin-bottom: 20px; padding: 15px; border-radius: 8px; page-break-inside: avoid; }
          .user { background-color: #e3f2fd; margin-left: 20%; }
          .assistant { background-color: #f5f5f5; margin-right: 20%; }
          .sender { font-weight: bold; margin-bottom: 5px; color: #333; }
          .timestamp { font-size: 12px; color: #666; margin-bottom: 10px; }
          .content { white-space: pre-wrap; }
          .media-info { margin-top: 10px; padding: 8px; background-color: rgba(0,0,0,0.05); border-radius: 4px; font-size: 14px; }
          .links { margin-top: 10px; }
          .link { display: block; color: #1976d2; text-decoration: none; margin: 2px 0; }
          .link:hover { text-decoration: underline; }
          img { max-width: 100%; height: auto; margin: 10px 0; border-radius: 4px; }
          @media print { body { margin: 20px; } .message { break-inside: avoid; } }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>${conversationTitle}</h1>
          <p>Generated on ${new Date().toLocaleString()}</p>
          <p>M.S.A.A.I - Multi-System Autonomous Artificial Intelligence</p>
        </div>
        ${messages
          .map((msg) => {
            let mediaContent = ""

            // Add image information
            if (msg.imageUrl && msg.imagePrompt) {
              mediaContent += `<div class="media-info"><strong>Generated Image:</strong> "${msg.imagePrompt}"</div>`
            }

            // Add file information
            if (msg.fileUrl && msg.fileName) {
              mediaContent += `<div class="media-info"><strong>Uploaded File:</strong> ${msg.fileName} (${msg.fileType})`
              if (msg.fileAnalysis) {
                mediaContent += `<br><strong>Analysis:</strong> ${msg.fileAnalysis}`
              }
              mediaContent += `</div>`
            }

            // Add links
            if (msg.multiModal?.links && msg.multiModal.links.length > 0) {
              mediaContent += `<div class="links"><strong>Related Links:</strong><br>`
              msg.multiModal.links.forEach((link: any) => {
                mediaContent += `<a href="${link.url}" class="link">${link.title}</a>`
              })
              mediaContent += `</div>`
            }

            return `
              <div class="message ${msg.role}">
                <div class="sender">${msg.role === "user" ? "You" : "M.S.A.A.I"}</div>
                <div class="timestamp">${new Date(msg.created_at).toLocaleString()}</div>
                <div class="content">${msg.content}</div>
                ${mediaContent}
              </div>
            `
          })
          .join("")}
      </body>
      </html>
    `

    const blob = new Blob([htmlContent], { type: "text/html" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${conversationTitle}.html`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast.success("Chat downloaded as HTML file (can be printed as PDF)")
  }

  const downloadAsJSON = () => {
    if (messages.length === 0) {
      toast.error("No messages to download")
      return
    }

    const exportData = {
      title: conversationTitle,
      exportedAt: new Date().toISOString(),
      messageCount: messages.length,
      messages: messages.map((msg) => ({
        id: msg.id,
        content: msg.content,
        role: msg.role,
        created_at: msg.created_at,
        ...(msg.imageUrl && { image: { url: msg.imageUrl, prompt: msg.imagePrompt } }),
        ...(msg.fileUrl && {
          file: { url: msg.fileUrl, name: msg.fileName, type: msg.fileType, analysis: msg.fileAnalysis },
        }),
        ...(msg.multiModal && { multiModal: msg.multiModal }),
      })),
    }

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${conversationTitle}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast.success("Chat downloaded as JSON file")
  }

  const downloadAllImages = () => {
    const imageMessages = messages.filter((msg) => msg.imageUrl)

    if (imageMessages.length === 0) {
      toast.error("No images to download")
      return
    }

    imageMessages.forEach((msg, index) => {
      if (msg.imageUrl) {
        const a = document.createElement("a")
        a.href = msg.imageUrl
        a.download = `${conversationTitle}_image_${index + 1}_${msg.imagePrompt?.slice(0, 30).replace(/[^a-zA-Z0-9]/g, "_") || "generated"}.png`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
      }
    })

    toast.success(`Downloaded ${imageMessages.length} image(s)`)
  }

  const downloadCompleteArchive = async () => {
    if (messages.length === 0) {
      toast.error("No messages to download")
      return
    }

    // Create a comprehensive archive manifest
    const archiveManifest = {
      title: conversationTitle,
      exportedAt: new Date().toISOString(),
      messageCount: messages.length,
      imageCount: messages.filter((msg) => msg.imageUrl).length,
      fileCount: messages.filter((msg) => msg.fileUrl).length,
      contents: [
        "conversation.txt - Full conversation in text format",
        "conversation.html - Formatted conversation for PDF printing",
        "conversation.json - Complete data with metadata",
        ...(messages.some((msg) => msg.imageUrl) ? ["images/ - All generated images"] : []),
        ...(messages.some((msg) => msg.fileUrl) ? ["files/ - All uploaded files"] : []),
      ],
      instructions: "This archive contains your complete M.S.A.A.I conversation with all media and metadata preserved.",
    }

    const blob = new Blob([JSON.stringify(archiveManifest, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${conversationTitle}_archive_manifest.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    // Also trigger other downloads
    setTimeout(() => downloadAsText(), 500)
    setTimeout(() => downloadAsPDF(), 1000)
    setTimeout(() => downloadAsJSON(), 1500)
    if (messages.some((msg) => msg.imageUrl)) {
      setTimeout(() => downloadAllImages(), 2000)
    }

    toast.success("Complete archive download started")
  }

  if (messages.length === 0) return null

  const hasImages = messages.some((msg) => msg.imageUrl)
  const hasFiles = messages.some((msg) => msg.fileUrl)

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm">
          <Download className="w-4 h-4 mr-2" />
          Export
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuItem onClick={downloadAsText}>
          <FileText className="w-4 h-4 mr-2" />
          Download as TXT
        </DropdownMenuItem>
        <DropdownMenuItem onClick={downloadAsPDF}>
          <File className="w-4 h-4 mr-2" />
          Download as HTML/PDF
        </DropdownMenuItem>
        <DropdownMenuItem onClick={downloadAsJSON}>
          <FileJson className="w-4 h-4 mr-2" />
          Download as JSON
        </DropdownMenuItem>

        {(hasImages || hasFiles) && <DropdownMenuSeparator />}

        {hasImages && (
          <DropdownMenuItem onClick={downloadAllImages}>
            <ImageIcon className="w-4 h-4 mr-2" />
            Download All Images
          </DropdownMenuItem>
        )}

        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={downloadCompleteArchive}>
          <Archive className="w-4 h-4 mr-2" />
          Download Complete Archive
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
