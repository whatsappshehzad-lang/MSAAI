"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, Download, ImageIcon } from "lucide-react"
import { ConfirmationDialog } from "@/components/confirmation-dialog"

interface ImageGeneratorProps {
  onImageGenerated?: (imageUrl: string, prompt: string) => void
}

export function ImageGenerator({ onImageGenerated }: ImageGeneratorProps) {
  const [prompt, setPrompt] = useState("")
  const [style, setStyle] = useState("realistic")
  const [size, setSize] = useState("1024x1024")
  const [isGenerating, setIsGenerating] = useState(false)
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [generatedImage, setGeneratedImage] = useState<{
    url: string
    prompt: string
    downloadUrl: string
  } | null>(null)

  const handleGenerateClick = () => {
    if (!prompt.trim()) return
    setShowConfirmation(true)
  }

  const handleConfirmGenerate = async () => {
    setShowConfirmation(false)
    setIsGenerating(true)

    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, style, size }),
      })

      const data = await response.json()

      if (data.success) {
        const imageData = {
          url: data.imageUrl,
          prompt: data.prompt,
          downloadUrl: data.downloadUrl,
        }
        setGeneratedImage(imageData)
        onImageGenerated?.(data.imageUrl, data.prompt)
      } else {
        console.error("Image generation failed:", data.error)
      }
    } catch (error) {
      console.error("Error generating image:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleDownload = () => {
    if (generatedImage) {
      const link = document.createElement("a")
      link.href = generatedImage.downloadUrl
      link.download = `msaai-generated-${Date.now()}.png`
      link.click()
    }
  }

  return (
    <>
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ImageIcon className="h-5 w-5" />
            Image Generation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Input
              placeholder="Describe the image you want to generate..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !isGenerating && handleGenerateClick()}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Style</label>
              <Select value={style} onValueChange={setStyle}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="realistic">Realistic</SelectItem>
                  <SelectItem value="artistic">Artistic</SelectItem>
                  <SelectItem value="cartoon">Cartoon</SelectItem>
                  <SelectItem value="abstract">Abstract</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Size</label>
              <Select value={size} onValueChange={setSize}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="512x512">512x512</SelectItem>
                  <SelectItem value="1024x1024">1024x1024</SelectItem>
                  <SelectItem value="1024x768">1024x768</SelectItem>
                  <SelectItem value="768x1024">768x1024</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button onClick={handleGenerateClick} disabled={!prompt.trim() || isGenerating} className="w-full">
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Image"
            )}
          </Button>

          {generatedImage && (
            <div className="space-y-4 pt-4 border-t">
              <div className="relative">
                <img
                  src={generatedImage.url || "/placeholder.svg"}
                  alt={generatedImage.prompt}
                  className="w-full rounded-lg shadow-lg"
                />
              </div>
              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">"{generatedImage.prompt}"</p>
                <Button onClick={handleDownload} variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <ConfirmationDialog
        isOpen={showConfirmation}
        onClose={() => setShowConfirmation(false)}
        onConfirm={handleConfirmGenerate}
        title="Generate Image"
        message={`Do you want to generate an image with the following prompt?`}
        confirmText="Generate"
        cancelText="Cancel"
        type="info"
        details={[
          `Prompt: "${prompt}"`,
          `Style: ${style}`,
          `Size: ${size}`,
          "This will use AI resources to create your image",
        ]}
      />
    </>
  )
}
