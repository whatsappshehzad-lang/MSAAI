"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Brain, Languages, FileText, Code, Calculator, Newspaper, Cloud, Sparkles, X } from "lucide-react"

interface SmartModesProps {
  onModeSelect: (mode: string, prompt: string) => void
  isOpen: boolean
  onClose: () => void
}

export function SmartModes({ onModeSelect, isOpen, onClose }: SmartModesProps) {
  const [selectedMode, setSelectedMode] = useState<string | null>(null)
  const [inputText, setInputText] = useState("")
  const [targetLanguage, setTargetLanguage] = useState("")
  const [explanationLevel, setExplanationLevel] = useState("simple")

  if (!isOpen) return null

  const modes = [
    {
      id: "summarize",
      name: "📑 Summarize",
      icon: FileText,
      description: "Get concise summaries of text or conversations",
      color: "bg-blue-50 dark:bg-blue-950/30 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800",
    },
    {
      id: "translate",
      name: "🌍 Translate",
      icon: Languages,
      description: "Translate text between different languages",
      color:
        "bg-green-50 dark:bg-green-950/30 text-green-600 dark:text-green-400 border-green-200 dark:border-green-800",
    },
    {
      id: "explain-simple",
      name: "💡 Explain Simple",
      icon: Brain,
      description: "Get simple, easy-to-understand explanations",
      color:
        "bg-purple-50 dark:bg-purple-950/30 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800",
    },
    {
      id: "explain-deep",
      name: "📘 Explain Deep",
      icon: Sparkles,
      description: "Get detailed, comprehensive explanations",
      color:
        "bg-indigo-50 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800",
    },
    {
      id: "code",
      name: "💻 Code Mode",
      icon: Code,
      description: "Programming help, code review, and debugging",
      color:
        "bg-orange-50 dark:bg-orange-950/30 text-orange-600 dark:text-orange-400 border-orange-200 dark:border-orange-800",
    },
    {
      id: "calculator",
      name: "🧮 Calculator",
      icon: Calculator,
      description: "Mathematical calculations and problem solving",
      color: "bg-red-50 dark:bg-red-950/30 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800",
      comingSoon: true,
    },
    {
      id: "news",
      name: "📰 News",
      icon: Newspaper,
      description: "Get latest news and current events",
      color:
        "bg-yellow-50 dark:bg-yellow-950/30 text-yellow-600 dark:text-yellow-400 border-yellow-200 dark:border-yellow-800",
      comingSoon: true,
    },
    {
      id: "weather",
      name: "☁️ Weather",
      icon: Cloud,
      description: "Weather information and forecasts",
      color: "bg-cyan-50 dark:bg-cyan-950/30 text-cyan-600 dark:text-cyan-400 border-cyan-200 dark:border-cyan-800",
      comingSoon: true,
    },
  ]

  const handleModeSelect = (modeId: string) => {
    if (modes.find((m) => m.id === modeId)?.comingSoon) return
    setSelectedMode(modeId)
  }

  const handleSubmit = () => {
    if (!selectedMode || !inputText.trim()) return

    let prompt = ""

    switch (selectedMode) {
      case "summarize":
        prompt = `/summarize ${inputText}`
        break
      case "translate":
        if (!targetLanguage) {
          alert("Please select a target language")
          return
        }
        prompt = `/translate ${inputText} ${targetLanguage}`
        break
      case "explain-simple":
        prompt = `/explain ${inputText} (explain in simple terms)`
        break
      case "explain-deep":
        prompt = `/explain ${inputText} (provide detailed explanation)`
        break
      case "code":
        prompt = `[CODE MODE] ${inputText}`
        break
      default:
        prompt = inputText
    }

    onModeSelect(selectedMode, prompt)
    setSelectedMode(null)
    setInputText("")
    setTargetLanguage("")
    onClose()
  }

  const handleBack = () => {
    setSelectedMode(null)
    setInputText("")
    setTargetLanguage("")
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center text-xl font-bold">
                <Sparkles className="w-6 h-6 mr-2" />
                Smart Modes
              </CardTitle>
              <CardDescription className="text-base mt-1">
                Choose a specialized mode for enhanced AI assistance
              </CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {!selectedMode ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {modes.map((mode) => {
                const Icon = mode.icon
                return (
                  <div
                    key={mode.id}
                    className={`
                      relative p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 
                      ${mode.color} 
                      ${
                        mode.comingSoon
                          ? "opacity-60 cursor-not-allowed"
                          : "hover:scale-105 hover:shadow-lg hover:shadow-current/20"
                      }
                      min-h-[120px] flex flex-col justify-between
                      shadow-sm
                    `}
                    onClick={() => !mode.comingSoon && handleModeSelect(mode.id)}
                    style={{ lineHeight: "1.5" }}
                  >
                    <div className="flex flex-col items-center text-center space-y-2">
                      <Icon className="w-8 h-8 flex-shrink-0" />
                      <div className="font-bold text-lg leading-tight">{mode.name}</div>
                      <div className="text-sm opacity-80 leading-relaxed">{mode.description}</div>
                    </div>
                    {mode.comingSoon && (
                      <div className="absolute top-2 right-2">
                        <span className="text-xs bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-1 rounded-full">
                          Soon
                        </span>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm" onClick={handleBack}>
                  ← Back
                </Button>
                <div className="flex items-center space-x-2">
                  {(() => {
                    const mode = modes.find((m) => m.id === selectedMode)
                    const Icon = mode?.icon || Brain
                    return (
                      <>
                        <Icon className="w-5 h-5" />
                        <span className="font-medium">{mode?.name}</span>
                      </>
                    )
                  })()}
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="input-text">
                    {selectedMode === "summarize" && "Text to summarize"}
                    {selectedMode === "translate" && "Text to translate"}
                    {(selectedMode === "explain-simple" || selectedMode === "explain-deep") && "Topic to explain"}
                    {selectedMode === "code" && "Code or programming question"}
                  </Label>
                  <Textarea
                    id="input-text"
                    placeholder={
                      selectedMode === "summarize"
                        ? "Paste the text you want summarized..."
                        : selectedMode === "translate"
                          ? "Enter text to translate..."
                          : selectedMode === "code"
                            ? "Paste your code or describe your programming question..."
                            : "Enter your topic or question..."
                    }
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    rows={4}
                  />
                </div>

                {selectedMode === "translate" && (
                  <div>
                    <Label htmlFor="target-language">Target Language</Label>
                    <Select value={targetLanguage} onValueChange={setTargetLanguage}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select target language" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="spanish">Spanish</SelectItem>
                        <SelectItem value="french">French</SelectItem>
                        <SelectItem value="german">German</SelectItem>
                        <SelectItem value="italian">Italian</SelectItem>
                        <SelectItem value="portuguese">Portuguese</SelectItem>
                        <SelectItem value="chinese">Chinese</SelectItem>
                        <SelectItem value="japanese">Japanese</SelectItem>
                        <SelectItem value="korean">Korean</SelectItem>
                        <SelectItem value="arabic">Arabic</SelectItem>
                        <SelectItem value="hindi">Hindi</SelectItem>
                        <SelectItem value="russian">Russian</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="flex space-x-2">
                  <Button onClick={handleSubmit} disabled={!inputText.trim()} className="flex-1">
                    Apply {modes.find((m) => m.id === selectedMode)?.name} Mode
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
