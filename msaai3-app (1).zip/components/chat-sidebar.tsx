"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, MessageSquare, Plus, X, Menu } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  created_at: string
}

interface Conversation {
  id: string
  title: string
  created_at: string
  updated_at: string
  messages: Message[]
}

interface ChatSidebarProps {
  currentConversationId: string | null
  onConversationSelect: (conversationId: string) => void
  onNewConversation: () => void
  isOpen: boolean
  onToggle: () => void
}

export function ChatSidebar({
  currentConversationId,
  onConversationSelect,
  onNewConversation,
  isOpen,
  onToggle,
}: ChatSidebarProps) {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClient()

  const fetchConversations = async (search?: string) => {
    try {
      const url = new URL("/api/conversations", window.location.origin)
      if (search) {
        url.searchParams.set("search", search)
      }

      const response = await fetch(url.toString())
      const data = await response.json()

      if (response.ok) {
        setConversations(data.conversations || [])
      }
    } catch (error) {
      console.error("Error fetching conversations:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchConversations()
  }, [])

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      fetchConversations(searchQuery)
    }, 300)

    return () => clearTimeout(timeoutId)
  }, [searchQuery])

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } else if (diffInHours < 168) {
      // 7 days
      return date.toLocaleDateString([], { weekday: "short" })
    } else {
      return date.toLocaleDateString([], { month: "short", day: "numeric" })
    }
  }

  const getPreviewText = (conversation: Conversation) => {
    const lastMessage = conversation.messages?.[conversation.messages.length - 1]
    if (!lastMessage) return "No messages yet"

    const preview = lastMessage.content.length > 50 ? lastMessage.content.substring(0, 50) + "..." : lastMessage.content

    return `${lastMessage.role === "user" ? "You: " : "M.S.A.A.I: "}${preview}`
  }

  if (!isOpen) {
    return (
      <Button variant="ghost" size="icon" onClick={onToggle} className="fixed top-4 left-4 z-50 md:hidden">
        <Menu className="w-5 h-5" />
      </Button>
    )
  }

  return (
    <>
      {/* Mobile overlay */}
      <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={onToggle} />

      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-80 bg-white border-r border-gray-200 z-50 md:relative md:z-0">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Chat History</h2>
              <Button variant="ghost" size="icon" onClick={onToggle} className="md:hidden">
                <X className="w-5 h-5" />
              </Button>
            </div>

            <Button onClick={onNewConversation} className="w-full mb-4" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              New Chat
            </Button>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Conversations List */}
          <ScrollArea className="flex-1">
            <div className="p-2">
              {isLoading ? (
                <div className="text-center py-8 text-gray-500">Loading conversations...</div>
              ) : conversations.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  {searchQuery ? "No conversations found" : "No conversations yet"}
                </div>
              ) : (
                conversations.map((conversation) => (
                  <Button
                    key={conversation.id}
                    variant={currentConversationId === conversation.id ? "secondary" : "ghost"}
                    className="w-full justify-start p-3 h-auto mb-2 text-left"
                    onClick={() => {
                      onConversationSelect(conversation.id)
                      if (window.innerWidth < 768) {
                        onToggle()
                      }
                    }}
                  >
                    <div className="flex items-start space-x-3 w-full">
                      <MessageSquare className="w-4 h-4 mt-1 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-medium text-sm truncate">{conversation.title}</h3>
                          <span className="text-xs text-gray-500 flex-shrink-0 ml-2">
                            {formatDate(conversation.updated_at)}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 truncate">{getPreviewText(conversation)}</p>
                      </div>
                    </div>
                  </Button>
                ))
              )}
            </div>
          </ScrollArea>
        </div>
      </div>
    </>
  )
}
