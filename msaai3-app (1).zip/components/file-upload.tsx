"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, Camera, FileText, ImageIcon, X, Loader2 } from "lucide-react"
import { ConfirmationDialog } from "@/components/confirmation-dialog"

interface FileUploadProps {
  onFileUploaded?: (file: any) => void
  onClose?: () => void
}

export function FileUpload({ onFileUploaded, onClose }: FileUploadProps) {
  const [isUploading, setIsUploading] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [cameraActive, setCameraActive] = useState(false)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [showCameraConfirmation, setShowCameraConfirmation] = useState(false)
  const [showUploadConfirmation, setShowUploadConfirmation] = useState(false)
  const [pendingFile, setPendingFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const handleFileSelect = (file: File) => {
    if (!file) return
    setPendingFile(file)
    setShowUploadConfirmation(true)
  }

  const handleConfirmUpload = async () => {
    if (!pendingFile) return

    setShowUploadConfirmation(false)
    setIsUploading(true)

    try {
      const formData = new FormData()
      formData.append("file", pendingFile)

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        onFileUploaded?.(data.file)
      } else {
        console.error("Upload failed:", data.error)
        alert(data.error)
      }
    } catch (error) {
      console.error("Error uploading file:", error)
      alert("Failed to upload file")
    } finally {
      setIsUploading(false)
      setPendingFile(null)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragActive(false)

    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setDragActive(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setDragActive(false)
  }

  const handleCameraClick = () => {
    setShowCameraConfirmation(true)
  }

  const handleConfirmCamera = async () => {
    setShowCameraConfirmation(false)

    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })
      setStream(mediaStream)
      setCameraActive(true)

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
      }
    } catch (error) {
      console.error("Error accessing camera:", error)
      alert("Could not access camera. Please check permissions.")
    }
  }

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }
    setCameraActive(false)
  }

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    if (!context) return

    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    context.drawImage(video, 0, 0)

    canvas.toBlob(
      (blob) => {
        if (blob) {
          const file = new File([blob], `camera-capture-${Date.now()}.jpg`, {
            type: "image/jpeg",
          })
          handleFileSelect(file)
          stopCamera()
        }
      },
      "image/jpeg",
      0.8,
    )
  }

  return (
    <>
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            File Upload & Camera
          </CardTitle>
          {onClose && (
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          {!cameraActive ? (
            <>
              {/* Drag and Drop Area */}
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive ? "border-blue-500 bg-blue-50 dark:bg-blue-950" : "border-gray-300 dark:border-gray-600"
                }`}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
              >
                <div className="space-y-4">
                  <div className="flex justify-center">
                    <Upload className="h-12 w-12 text-gray-400" />
                  </div>
                  <div>
                    <p className="text-lg font-medium">Drop files here</p>
                    <p className="text-sm text-gray-500">or click to browse (max 10MB)</p>
                  </div>
                  <div className="flex flex-wrap justify-center gap-2 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <ImageIcon className="h-3 w-3" />
                      Images
                    </span>
                    <span className="flex items-center gap-1">
                      <FileText className="h-3 w-3" />
                      PDF, Text, CSV
                    </span>
                  </div>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  accept="image/*,.pdf,.txt,.csv,.json"
                  onChange={(e) => {
                    const file = e.target.files?.[0]
                    if (file) handleFileSelect(file)
                  }}
                  disabled={isUploading}
                />
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-4">
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="w-full"
                >
                  {isUploading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Browse Files
                    </>
                  )}
                </Button>

                <Button
                  variant="outline"
                  onClick={handleCameraClick}
                  disabled={isUploading}
                  className="w-full bg-transparent"
                >
                  <Camera className="mr-2 h-4 w-4" />
                  Use Camera
                </Button>
              </div>
            </>
          ) : (
            /* Camera Interface */
            <div className="space-y-4">
              <div className="relative bg-black rounded-lg overflow-hidden">
                <video ref={videoRef} autoPlay playsInline className="w-full h-64 object-cover" />
                <canvas ref={canvasRef} className="hidden" />
              </div>

              <div className="flex justify-center gap-4">
                <Button onClick={capturePhoto} size="lg">
                  <Camera className="mr-2 h-4 w-4" />
                  Capture Photo
                </Button>
                <Button variant="outline" onClick={stopCamera}>
                  Cancel
                </Button>
              </div>
            </div>
          )}

          <div className="text-xs text-gray-500 text-center">
            Supported: Images (JPG, PNG, GIF, WebP), PDF, Text files, CSV (max 10MB)
          </div>
        </CardContent>
      </Card>

      <ConfirmationDialog
        isOpen={showCameraConfirmation}
        onClose={() => setShowCameraConfirmation(false)}
        onConfirm={handleConfirmCamera}
        title="Access Camera"
        message="M.S.A.A.I would like to access your camera to capture photos."
        confirmText="Allow Camera"
        cancelText="Cancel"
        type="info"
        details={[
          "This will request camera permissions",
          "You can capture photos directly in the app",
          "Photos will be processed and analyzed by M.S.A.A.I",
        ]}
      />

      <ConfirmationDialog
        isOpen={showUploadConfirmation}
        onClose={() => {
          setShowUploadConfirmation(false)
          setPendingFile(null)
        }}
        onConfirm={handleConfirmUpload}
        title="Upload File"
        message={`Do you want to upload this file?`}
        confirmText="Upload"
        cancelText="Cancel"
        type="info"
        details={
          pendingFile
            ? [
                `File: ${pendingFile.name}`,
                `Size: ${(pendingFile.size / 1024 / 1024).toFixed(2)} MB`,
                `Type: ${pendingFile.type}`,
                "File will be analyzed by M.S.A.A.I",
              ]
            : []
        }
      />
    </>
  )
}
